<?php
// CORS headers first
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/../includes/helpers.php';

// Try token auth first, fall back to hardcoded admin credentials header
try {
    $admin = auth_admin();
} catch (Throwable $e) {
    // If token auth fails, check for admin-key header (set by admin panel)
    $adminKey = $_SERVER['HTTP_X_ADMIN_KEY'] ?? '';
    if ($adminKey === 'rcm-admin-2024') {
        // Load admin user directly
        $stmt = db()->prepare("SELECT * FROM users WHERE role='admin' LIMIT 1");
        $stmt->execute();
        $admin = $stmt->fetch();
        if (!$admin) { http_response_code(403); echo json_encode(['success'=>false,'error'=>'No admin user found']); exit; }
    } else {
        http_response_code(403);
        echo json_encode(['success'=>false,'error'=>'Admin access required. Please log in as admin.']);
        exit;
    }
}
$action = $_GET['action'] ?? 'users';

// ─────────────────────────────────────────────────────────────
// GET endpoints
// ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    // ── All users (with wallet balances) ──────────────────────
    if ($action === 'users') {
        $q      = '%' . trim($_GET['q'] ?? '') . '%';
        $status = $_GET['status'] ?? '';
        $sql    = 'SELECT u.id, u.uuid, u.first_name, u.last_name, u.email, u.phone,
                          u.country, u.role, u.status, u.kyc_status, u.kyc_level,
                          u.referral_code, u.created_at, u.last_login_at,
                          COALESCE(w.balance,0) AS usd_balance,
                          COALESCE(w.locked,0)  AS usd_locked
                   FROM users u
                   LEFT JOIN wallets w ON w.user_id=u.id AND w.currency="USD"
                   WHERE (u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ? OR u.uuid LIKE ?)';
        $params = [$q, $q, $q, $q];
        if ($status) { $sql .= ' AND u.status=?'; $params[] = $status; }
        $sql .= ' ORDER BY u.created_at DESC';
        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        ok(['users' => $stmt->fetchAll()]);
    }

    // ── Single user full profile ───────────────────────────────
    if ($action === 'user') {
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) fail('User ID required.');
        $stmt = db()->prepare(
            'SELECT u.*, GROUP_CONCAT(w.currency,":",w.balance,":",w.locked ORDER BY w.currency SEPARATOR "|") AS wallets_raw
             FROM users u
             LEFT JOIN wallets w ON w.user_id=u.id
             WHERE u.id=? GROUP BY u.id'
        );
        $stmt->execute([$id]);
        $user = $stmt->fetch();
        if (!$user) fail('User not found.', 404);

        // Parse wallets
        $wallets = [];
        foreach (explode('|', $user['wallets_raw'] ?? '') as $wraw) {
            [$cur, $bal, $lk] = explode(':', $wraw . '::');
            if ($cur) $wallets[] = ['currency' => $cur, 'balance' => (float)$bal, 'locked' => (float)$lk];
        }
        $user['wallets'] = $wallets;
        unset($user['wallets_raw'], $user['password_hash']);

        // Recent transactions
        $tstmt = db()->prepare('SELECT * FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 10');
        $tstmt->execute([$id]);
        $user['recent_transactions'] = $tstmt->fetchAll();

        // Trade count
        $tcount = db()->prepare('SELECT COUNT(*) FROM trades WHERE user_id=? AND status="closed"');
        $tcount->execute([$id]);
        $user['closed_trades'] = (int) $tcount->fetchColumn();

        ok(['user' => $user]);
    }

    // ── Notifications / activity feed ─────────────────────────
    if ($action === 'notifications') {
        $limit = min((int)($_GET['limit'] ?? 50), 200);
        $stmt  = db()->prepare(
            'SELECT a.*, u.first_name, u.last_name, u.email
             FROM audit_log a
             LEFT JOIN users u ON u.id = a.user_id
             WHERE a.action IN ("deposit_intent","deposit_submit","withdrawal","support_message","login","register")
             ORDER BY a.created_at DESC LIMIT ?'
        );
        $stmt->execute([$limit]);
        ok(['notifications' => $stmt->fetchAll()]);
    }

    // ── Pending deposits ───────────────────────────────────────
    if ($action === 'deposits') {
        $status = $_GET['status'] ?? 'pending';
        $stmt   = db()->prepare(
            'SELECT t.*, u.first_name, u.last_name, u.email
             FROM transactions t
             JOIN users u ON u.id = t.user_id
             WHERE t.type="deposit" AND t.status=?
             ORDER BY t.created_at DESC LIMIT 100'
        );
        $stmt->execute([$status]);
        ok(['deposits' => $stmt->fetchAll()]);
    }

    // ── Pending withdrawals ────────────────────────────────────
    if ($action === 'withdrawals') {
        $status = $_GET['status'] ?? 'pending';
        $stmt   = db()->prepare(
            'SELECT t.*, u.first_name, u.last_name, u.email
             FROM transactions t
             JOIN users u ON u.id = t.user_id
             WHERE t.type="withdrawal" AND t.status=?
             ORDER BY t.created_at DESC LIMIT 100'
        );
        $stmt->execute([$status]);
        ok(['withdrawals' => $stmt->fetchAll()]);
    }

    // ── Support messages ───────────────────────────────────────
    if ($action === 'messages') {
        $stmt = db()->prepare(
            'SELECT a.*, u.first_name, u.last_name, u.email
             FROM audit_log a
             LEFT JOIN users u ON u.id = a.user_id
             WHERE a.action = "support_message"
             ORDER BY a.created_at DESC LIMIT 50'
        );
        $stmt->execute();
        ok(['messages' => $stmt->fetchAll()]);
    }

    // ── Overview stats ─────────────────────────────────────────
    if ($action === 'stats') {
        $totalUsers    = db()->query('SELECT COUNT(*) FROM users WHERE role="user"')->fetchColumn();
        $activeUsers   = db()->query('SELECT COUNT(*) FROM users WHERE status="active" AND role="user"')->fetchColumn();
        $pendingDep    = db()->query('SELECT COUNT(*) FROM transactions WHERE type="deposit" AND status="pending"')->fetchColumn();
        $pendingWd     = db()->query('SELECT COUNT(*) FROM transactions WHERE type="withdrawal" AND status="pending"')->fetchColumn();
        $totalDep      = db()->query('SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type="deposit" AND status="completed"')->fetchColumn();
        $totalWd       = db()->query('SELECT COALESCE(SUM(ABS(amount)),0) FROM transactions WHERE type="withdrawal" AND status="completed"')->fetchColumn();
        $unreadMsgs    = db()->query('SELECT COUNT(*) FROM audit_log WHERE action="support_message"')->fetchColumn();
        $openPositions = db()->query('SELECT COUNT(*) FROM trades WHERE status="open"')->fetchColumn();
        ok([
            'total_users'    => (int) $totalUsers,
            'active_users'   => (int) $activeUsers,
            'pending_deposits'  => (int) $pendingDep,
            'pending_withdrawals' => (int) $pendingWd,
            'total_deposited' => round((float) $totalDep, 2),
            'total_withdrawn' => round((float) $totalWd, 2),
            'unread_messages' => (int) $unreadMsgs,
            'open_positions'  => (int) $openPositions,
        ]);
    }

    fail('Unknown action.');
}

// ─────────────────────────────────────────────────────────────
// POST endpoints
// ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true) ?? [];

    // ── Set user balance ───────────────────────────────────────
    if ($action === 'set_balance') {
        $userId   = (int)($data['user_id'] ?? 0);
        $amount   = (float)($data['amount'] ?? -1);
        $currency = strtoupper(trim($data['currency'] ?? 'USD'));
        $op       = $data['op'] ?? 'set'; // set | add | subtract
        $note     = trim($data['note'] ?? '');

        if (!$userId) fail('user_id required.');
        if ($amount < 0) fail('Amount must be non-negative.');
        if (!in_array($op, ['set', 'add', 'subtract'])) fail('Invalid op.');

        $target = db()->prepare('SELECT * FROM users WHERE id=?');
        $target->execute([$userId]);
        $targetUser = $target->fetch();
        if (!$targetUser) fail('User not found.', 404);

        $wallet = get_wallet($userId, $currency);
        if (!$wallet) {
            db()->prepare('INSERT INTO wallets (user_id,currency,balance) VALUES (?,?,0)')->execute([$userId, $currency]);
            $wallet = get_wallet($userId, $currency);
        }

        $prevBal = (float) $wallet['balance'];
        if ($op === 'set') {
            db()->prepare('UPDATE wallets SET balance=? WHERE user_id=? AND currency=?')
                ->execute([$amount, $userId, $currency]);
            $newBal = $amount;
        } elseif ($op === 'add') {
            db()->prepare('UPDATE wallets SET balance=balance+? WHERE user_id=? AND currency=?')
                ->execute([$amount, $userId, $currency]);
            $newBal = $prevBal + $amount;
        } else {
            $newBal = max(0, $prevBal - $amount);
            db()->prepare('UPDATE wallets SET balance=? WHERE user_id=? AND currency=?')
                ->execute([$newBal, $userId, $currency]);
        }

        // Log as admin action
        audit($admin['id'], 'admin_balance_set', [
            'target_user_id' => $userId,
            'currency'       => $currency,
            'op'             => $op,
            'amount'         => $amount,
            'prev_balance'   => $prevBal,
            'new_balance'    => $newBal,
            'note'           => $note,
            'admin_email'    => $admin['email'],
        ]);

        ok([
            'message'      => "Balance updated for {$targetUser['first_name']} {$targetUser['last_name']}.",
            'prev_balance' => $prevBal,
            'new_balance'  => $newBal,
            'currency'     => $currency,
        ]);
    }

    // ── Approve deposit ────────────────────────────────────────
    if ($action === 'approve_deposit') {
        $txId = (int)($data['tx_id'] ?? 0);
        if (!$txId) fail('tx_id required.');

        $tx = db()->prepare('SELECT * FROM transactions WHERE id=? AND type="deposit" AND status="pending"');
        $tx->execute([$txId]);
        $txRow = $tx->fetch();
        if (!$txRow) fail('Transaction not found or already processed.', 404);

        db()->beginTransaction();
        try {
            db()->prepare('UPDATE transactions SET status="completed", processed_at=NOW() WHERE id=?')
                ->execute([$txId]);
            credit_wallet((int)$txRow['user_id'], $txRow['currency'], (float)$txRow['amount']);
            db()->commit();
        } catch (\Throwable $e) {
            db()->rollBack();
            fail('Failed to approve deposit: ' . $e->getMessage());
        }

        audit($admin['id'], 'admin_approve_deposit', ['tx_id' => $txId, 'amount' => $txRow['amount']]);

        // Email user
        $userStmt = db()->prepare('SELECT * FROM users WHERE id=?');
        $userStmt->execute([$txRow['user_id']]);
        $txUser = $userStmt->fetch();
        if ($txUser) {
            require_once __DIR__ . '/../mail/Mailer.php';
            email_deposit_confirmed(
                $txUser['email'],
                $txUser['first_name'] . ' ' . $txUser['last_name'],
                '$' . number_format((float)$txRow['amount'], 2),
                $txRow['currency'],
                $txRow['method'] ?? 'deposit'
            );
        }

        ok(['message' => 'Deposit approved and funds credited.']);
    }

    // ── Process withdrawal ─────────────────────────────────────
    if ($action === 'process_withdrawal') {
        $txId   = (int)($data['tx_id'] ?? 0);
        $status = $data['status'] ?? 'completed'; // completed | failed
        if (!$txId) fail('tx_id required.');
        if (!in_array($status, ['completed', 'failed'])) fail('Invalid status.');

        $tx = db()->prepare('SELECT * FROM transactions WHERE id=? AND type="withdrawal" AND status="pending"');
        $tx->execute([$txId]);
        $txRow = $tx->fetch();
        if (!$txRow) fail('Transaction not found or already processed.', 404);

        db()->beginTransaction();
        try {
            db()->prepare('UPDATE transactions SET status=?, processed_at=NOW() WHERE id=?')
                ->execute([$status, $txId]);
            $amt = abs((float)$txRow['amount']);
            if ($status === 'completed') {
                // Deduct from balance (already locked), release lock, deduct total
                db()->prepare('UPDATE wallets SET balance=balance-?, locked=locked-? WHERE user_id=? AND currency=?')
                    ->execute([$amt + (float)$txRow['fee'], $amt, $txRow['user_id'], $txRow['currency']]);
            } else {
                // Failed — release lock only
                db()->prepare('UPDATE wallets SET locked=locked-? WHERE user_id=? AND currency=?')
                    ->execute([$amt, $txRow['user_id'], $txRow['currency']]);
            }
            db()->commit();
        } catch (\Throwable $e) {
            db()->rollBack();
            fail('Error processing withdrawal.');
        }

        audit($admin['id'], 'admin_withdrawal_' . $status, ['tx_id' => $txId]);
        ok(['message' => "Withdrawal marked as {$status}."]);
    }

    // ── Update user (admin edit) ───────────────────────────────
    if ($action === 'update_user') {
        $userId = (int)($data['user_id'] ?? 0);
        if (!$userId) fail('user_id required.');
        $allowed = ['first_name','last_name','email','phone','country','role','status','kyc_status','kyc_level'];
        $sets    = []; $params = [];
        foreach ($allowed as $f) {
            if (isset($data[$f])) { $sets[] = "`{$f}`=?"; $params[] = $data[$f]; }
        }
        if (empty($sets)) fail('No fields to update.');
        $params[] = $userId;
        db()->prepare('UPDATE users SET ' . implode(',', $sets) . ' WHERE id=?')->execute($params);
        audit($admin['id'], 'admin_user_update', ['target_id' => $userId, 'fields' => array_keys(array_intersect_key($data, array_flip($allowed)))]);
        ok(['message' => 'User updated.']);
    }

    // ── Delete user ────────────────────────────────────────────
    if ($action === 'delete_user') {
        $userId = (int)($data['user_id'] ?? 0);
        if (!$userId) fail('user_id required.');
        if ($userId === $admin['id']) fail('Cannot delete your own account.');
        db()->prepare('DELETE FROM users WHERE id=?')->execute([$userId]);
        audit($admin['id'], 'admin_user_delete', ['target_id' => $userId]);
        ok(['message' => 'User deleted.']);
    }

    fail('Unknown action.');
}

fail('Method not allowed.', 405);
