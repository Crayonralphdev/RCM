<?php
// CORS headers first — before anything else can fail
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
// ============================================================
//  Retro Clurix Miners — Dashboard API
//  GET  /api/dashboard.php          → full dashboard data
//  POST /api/dashboard.php?action=X → actions
// ============================================================
require_once __DIR__ . '/../includes/helpers.php';
cors();

$user   = auth_user();
$uid    = (int) $user['id'];
$action = $_GET['action'] ?? 'data';

// ─────────────────────────────────────────────────────────────
// GET — load all dashboard data in one shot
// ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    // Wallets
    $wstmt = db()->prepare('SELECT currency, balance, locked FROM wallets WHERE user_id=?');
    $wstmt->execute([$uid]);
    $wallets = $wstmt->fetchAll();
    $usdWallet = array_filter($wallets, fn($w) => $w['currency'] === 'USD');
    $usdWallet = reset($usdWallet);
    $balance   = $usdWallet ? (float)$usdWallet['balance'] : 0.0;
    $locked    = $usdWallet ? (float)$usdWallet['locked']  : 0.0;

    // Open positions
    $pstmt = db()->prepare(
        'SELECT t.*, i.symbol, i.category FROM trades t
         JOIN instruments i ON i.id = t.instrument_id
         WHERE t.user_id=? AND t.status="open"
         ORDER BY t.opened_at DESC'
    );
    $pstmt->execute([$uid]);
    $positions = $pstmt->fetchAll();

    // Unrealized PnL (simplified: random simulation on open price, real impl would use live price feed)
    $unrealised = 0;
    foreach ($positions as &$p) {
        $p['open_price']  = (float) $p['open_price'];
        $p['margin_used'] = (float) $p['margin_used'];
        // Placeholder unrealised PnL — replace with live price calculation in production
        $p['unrealised_pnl'] = round((float)$p['margin_used'] * 0.034 * ($p['direction'] === 'long' ? 1 : -1), 2);
        $unrealised += $p['unrealised_pnl'];
    }
    unset($p);

    // Trade history (closed)
    $hstmt = db()->prepare(
        'SELECT t.*, i.symbol FROM trades t
         JOIN instruments i ON i.id = t.instrument_id
         WHERE t.user_id=? AND t.status="closed"
         ORDER BY t.closed_at DESC LIMIT 50'
    );
    $hstmt->execute([$uid]);
    $history = $hstmt->fetchAll();
    $wins  = count(array_filter($history, fn($t) => (float)$t['realised_pnl'] > 0));
    $total = count($history);

    // Transactions
    $tstmt = db()->prepare(
        'SELECT * FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 20'
    );
    $tstmt->execute([$uid]);
    $transactions = $tstmt->fetchAll();

    ok([
        'user' => [
            'uuid'          => $user['uuid'],
            'first_name'    => $user['first_name'],
            'last_name'     => $user['last_name'],
            'email'         => $user['email'],
            'phone'         => $user['phone'],
            'country'       => $user['country'],
            'experience'    => $user['experience'],
            'kyc_status'    => $user['kyc_status'],
            'kyc_level'     => (int) $user['kyc_level'],
            'role'          => $user['role'],
            'two_fa'        => (bool) $user['two_fa_enabled'],
            'referral_code' => $user['referral_code'],
            'last_login_at' => $user['last_login_at'],
        ],
        'wallets'      => $wallets,
        'balance'      => $balance,
        'available'    => $balance - $locked,
        'locked'       => $locked,
        'unrealised_pnl' => round($unrealised, 2),
        'positions'    => $positions,
        'history'      => $history,
        'trade_stats'  => [
            'total'    => $total,
            'wins'     => $wins,
            'losses'   => $total - $wins,
            'win_rate' => $total > 0 ? round($wins / $total * 100, 1) : 0,
        ],
        'transactions' => $transactions,
    ]);
}

// ─────────────────────────────────────────────────────────────
// POST actions
// ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true) ?? [];

    // ── Deposit intent (step 1: user enters amount) ───────────
    if ($action === 'deposit_intent') {
        $amt = (float)($data['amount'] ?? 0);
        if ($amt < 50) fail('Minimum deposit is $50.');

        $method = trim($data['method'] ?? 'unknown');

        // Notify admin via DB
        db()->prepare(
            'INSERT INTO audit_log (user_id, action, ip_address, details) VALUES (?,?,?,?)'
        )->execute([
            $uid, 'deposit_intent', $_SERVER['REMOTE_ADDR'] ?? '',
            json_encode([
                'amount'  => $amt,
                'method'  => $method,
                'status'  => 'selecting_payment',
                'user'    => $user['first_name'] . ' ' . $user['last_name'],
                'email'   => $user['email'],
            ])
        ]);

        // Send email to admin
        require_once __DIR__ . '/../mail/Mailer.php';
        send_email(
            'craralph@gmail.com',
            'Admin',
            "⚡ Deposit Intent: {$user['first_name']} {$user['last_name']} — \${$amt}",
            email_template('Deposit Intent', "
                <h2 style='color:#f0c040'>New Deposit Intent</h2>
                <p style='color:#8892aa'>A user has entered a deposit amount and is selecting a payment method.</p>
                <table style='width:100%;background:#131827;border-radius:10px;padding:16px;margin-top:16px'>
                  <tr><td style='color:#4a5468;padding:6px 0'>User</td><td style='color:#e2e6f0;font-weight:700'>{$user['first_name']} {$user['last_name']}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Email</td><td style='color:#e2e6f0'>{$user['email']}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Amount</td><td style='color:#1fd98a;font-weight:800;font-size:18px'>\${$amt}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Method</td><td style='color:#e2e6f0'>{$method}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Time</td><td style='color:#e2e6f0'>" . date('D d M Y H:i:s T') . "</td></tr>
                </table>
                <p style='color:#f0c040;margin-top:16px;font-size:13px'>Log in to the admin panel to review this deposit.</p>
            ")
        );

        ok(['message' => 'Admin notified.']);
    }

    // ── Submit deposit (user confirms payment sent) ────────────
    if ($action === 'deposit_submit') {
        $amt    = (float)($data['amount'] ?? 0);
        $method = trim($data['method'] ?? 'unknown');
        if ($amt < 50) fail('Minimum deposit is $50.');

        $txUuid = uuid4();
        $wallet = get_wallet($uid, 'USD');
        if (!$wallet) fail('USD wallet not found.');

        db()->prepare(
            'INSERT INTO transactions (uuid,user_id,wallet_id,type,currency,amount,fee,status,method)
             VALUES (?,?,?,?,?,?,?,?,?)'
        )->execute([$txUuid, $uid, $wallet['id'], 'deposit', 'USD', $amt, 0, 'pending', $method]);

        audit($uid, 'deposit_submit', ['amount' => $amt, 'method' => $method, 'tx_uuid' => $txUuid]);

        // Notify admin
        require_once __DIR__ . '/../mail/Mailer.php';
        send_email(
            'craralph@gmail.com',
            'Admin',
            "💰 Deposit Submitted: {$user['first_name']} {$user['last_name']} — \${$amt} via {$method}",
            email_template('Deposit Submitted', "
                <h2 style='color:#1fd98a'>Deposit Payment Submitted</h2>
                <p style='color:#8892aa'>User has confirmed they have sent payment. Please verify and approve.</p>
                <table style='width:100%;background:#131827;border-radius:10px;padding:16px;margin-top:16px'>
                  <tr><td style='color:#4a5468;padding:6px 0'>User</td><td style='color:#e2e6f0;font-weight:700'>{$user['first_name']} {$user['last_name']}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Email</td><td style='color:#e2e6f0'>{$user['email']}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Amount</td><td style='color:#1fd98a;font-weight:800;font-size:18px'>\${$amt}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Method</td><td style='color:#e2e6f0'>{$method}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>TX UUID</td><td style='color:#e2e6f0;font-family:monospace'>{$txUuid}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Status</td><td style='color:#f0c040;font-weight:700'>⏳ Pending Verification</td></tr>
                </table>
                <a href='https://retroclurixminers.net/admin.html' style='display:inline-block;margin-top:20px;padding:12px 24px;background:#f0c040;color:#0a0a0a;font-weight:800;border-radius:8px;text-decoration:none'>Review in Admin Panel →</a>
            ")
        );

        ok(['message' => 'Deposit submitted. Admin will verify and credit your account.', 'tx_uuid' => $txUuid]);
    }

    // ── Withdrawal request ─────────────────────────────────────
    if ($action === 'withdraw') {
        $amt    = (float)($data['amount'] ?? 0);
        $method = trim($data['method'] ?? '');
        $addr   = trim($data['address'] ?? '');
        if ($amt < 100) fail('Minimum withdrawal is $100.');
        if (!$addr) fail('Please provide a wallet address or bank account.');

        $wallet = get_wallet($uid, 'USD');
        if (!$wallet) fail('USD wallet not found.');
        $available = (float)$wallet['balance'] - (float)$wallet['locked'];
        if ($amt > $available) fail('Insufficient available balance.');

        $fee    = $method === 'bank_wire' ? 25 : min($amt * 0.005, 15);
        $txUuid = uuid4();

        db()->beginTransaction();
        try {
            db()->prepare('UPDATE wallets SET locked = locked + ? WHERE user_id=? AND currency=?')
                ->execute([$amt, $uid, 'USD']);
            db()->prepare(
                'INSERT INTO transactions (uuid,user_id,wallet_id,type,currency,amount,fee,status,method,address)
                 VALUES (?,?,?,?,?,?,?,?,?,?)'
            )->execute([$txUuid, $uid, $wallet['id'], 'withdrawal', 'USD', -$amt, $fee, 'pending', $method, $addr]);
            db()->commit();
        } catch (\Throwable $e) {
            db()->rollBack();
            fail('Could not process withdrawal. Please try again.');
        }

        audit($uid, 'withdrawal', ['amount' => $amt, 'method' => $method]);

        require_once __DIR__ . '/../mail/Mailer.php';
        send_email(
            'craralph@gmail.com',
            'Admin',
            "📤 Withdrawal Request: {$user['first_name']} {$user['last_name']} — \${$amt}",
            email_template('Withdrawal Request', "
                <h2 style='color:#f05565'>Withdrawal Request Received</h2>
                <table style='width:100%;background:#131827;border-radius:10px;padding:16px;margin-top:16px'>
                  <tr><td style='color:#4a5468;padding:6px 0'>User</td><td style='color:#e2e6f0;font-weight:700'>{$user['first_name']} {$user['last_name']}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Email</td><td style='color:#e2e6f0'>{$user['email']}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Amount</td><td style='color:#f05565;font-weight:800;font-size:18px'>\${$amt}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Fee</td><td style='color:#e2e6f0'>\${$fee}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Net Payout</td><td style='color:#f0c040;font-weight:700'>\$" . ($amt - $fee) . "</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Method</td><td style='color:#e2e6f0'>{$method}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Address</td><td style='color:#e2e6f0;font-family:monospace;font-size:12px'>{$addr}</td></tr>
                </table>
                <a href='https://retroclurixminers.net/admin.html' style='display:inline-block;margin-top:20px;padding:12px 24px;background:#f05565;color:#fff;font-weight:800;border-radius:8px;text-decoration:none'>Process Withdrawal →</a>
            ")
        );

        ok(['message' => "Withdrawal of \${$amt} submitted. Processing in 1–3 business days.", 'tx_uuid' => $txUuid]);
    }

    // ── Support message ────────────────────────────────────────
    if ($action === 'message') {
        $subject = trim($data['subject'] ?? '');
        $body    = trim($data['body'] ?? '');
        if (!$subject || !$body) fail('Subject and message body are required.');

        audit($uid, 'support_message', ['subject' => $subject]);

        require_once __DIR__ . '/../mail/Mailer.php';
        send_email(
            'craralph@gmail.com',
            'Admin',
            "💬 Support: {$user['first_name']} — {$subject}",
            email_template('Support Message', "
                <h2 style='color:#3d9cf0'>New Support Message</h2>
                <table style='width:100%;background:#131827;border-radius:10px;padding:16px;margin-top:16px;margin-bottom:16px'>
                  <tr><td style='color:#4a5468;padding:6px 0'>From</td><td style='color:#e2e6f0;font-weight:700'>{$user['first_name']} {$user['last_name']}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Email</td><td style='color:#e2e6f0'>{$user['email']}</td></tr>
                  <tr><td style='color:#4a5468;padding:6px 0'>Subject</td><td style='color:#e2e6f0;font-weight:700'>{$subject}</td></tr>
                </table>
                <div style='background:#0e1525;border-radius:10px;padding:18px;border:1px solid rgba(61,156,240,.2);font-size:14px;color:#8892aa;line-height:1.7'>
                " . nl2br(htmlspecialchars($body)) . "
                </div>
                <a href='https://retroclurixminers.net/admin.html' style='display:inline-block;margin-top:20px;padding:12px 24px;background:#3d9cf0;color:#fff;font-weight:800;border-radius:8px;text-decoration:none'>Reply in Admin Panel →</a>
            ")
        );

        ok(['message' => 'Your message has been sent. We\'ll reply within 24 hours.']);
    }

    // ── Update profile ─────────────────────────────────────────
    if ($action === 'update_profile') {
        $fn      = trim($data['first_name'] ?? $user['first_name']);
        $ln      = trim($data['last_name']  ?? $user['last_name']);
        $phone   = trim($data['phone'] ?? '');
        $country = trim($data['country'] ?? '');
        db()->prepare('UPDATE users SET first_name=?,last_name=?,phone=?,country=? WHERE id=?')
            ->execute([$fn, $ln, $phone ?: null, $country ?: null, $uid]);
        audit($uid, 'profile_update', []);
        ok(['message' => 'Profile updated successfully.']);
    }

    // ── Change password ────────────────────────────────────────
    if ($action === 'change_password') {
        $cur = $data['current_password'] ?? '';
        $new = $data['new_password'] ?? '';
        if (!password_verify($cur, $user['password_hash'])) fail('Current password is incorrect.');
        if (strlen($new) < 8 || !preg_match('/[A-Z]/', $new) || !preg_match('/[0-9]/', $new))
            fail('New password must be at least 8 chars with 1 uppercase and 1 number.');
        $hash = password_hash($new, PASSWORD_BCRYPT, ['cost' => 12]);
        db()->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([$hash, $uid]);
        audit($uid, 'password_change', []);
        ok(['message' => 'Password changed successfully.']);
    }

    fail('Unknown action: ' . htmlspecialchars($action));
}

fail('Method not allowed.', 405);
