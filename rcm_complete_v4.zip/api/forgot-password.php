<?php
// CORS headers first — before anything else can fail
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
// POST /api/forgot-password.php
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../mail/Mailer.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Method not allowed.', 405);

$data  = require_fields(['email']);
$email = strtolower(trim($data['email']));

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Invalid email address.');

$stmt = db()->prepare('SELECT id, first_name, last_name FROM users WHERE email=? AND status != "banned" LIMIT 1');
$stmt->execute([$email]);
$user = $stmt->fetch();

// Always return success to prevent email enumeration
if ($user) {
    $otp = create_otp((int)$user['id'], 'password_reset');
    Mailer::sendResetOTP($email, $user['first_name'] . ' ' . $user['last_name'], $otp);
    audit((int)$user['id'], 'password_reset_request', ['email' => $email]);
}

ok(['message' => 'If that email exists, a reset code has been sent.']);
