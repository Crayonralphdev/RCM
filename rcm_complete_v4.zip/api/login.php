<?php
// CORS headers first — before anything else can fail
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../mail/Mailer.php';
cors();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Method not allowed.', 405);
$data     = require_fields(['email','password']);
$email    = strtolower(trim($data['email']));
$password = $data['password'];

$stmt = db()->prepare('SELECT * FROM users WHERE email = ?');
$stmt->execute([$email]);
$user = $stmt->fetch();

$dummy = '$2y$12$invalid_hash_to_prevent_timing_attacks_xxxxxxxxxxx';
$valid = password_verify($password, $user ? $user['password_hash'] : $dummy);

if (!$user || !$valid) {
    if ($user) {
        $attempts = (int)$user['login_attempts'] + 1;
        if ($attempts >= MAX_LOGIN_ATTEMPTS) {
            $locked = date('Y-m-d H:i:s', time() + LOCK_DURATION_MIN * 60);
            db()->prepare('UPDATE users SET login_attempts=?,locked_until=? WHERE id=?')
                ->execute([$attempts,$locked,$user['id']]);
            fail('Too many failed attempts. Account locked for '.LOCK_DURATION_MIN.' minutes.',429);
        }
        db()->prepare('UPDATE users SET login_attempts=? WHERE id=?')->execute([$attempts,$user['id']]);
    }
    fail('Invalid email or password.',401);
}

if ($user['status']==='banned')     fail('This account has been permanently banned.',403);
if ($user['status']==='suspended')  fail('This account is temporarily suspended.',403);
if ($user['locked_until'] && strtotime($user['locked_until'])>time())
    fail('Account locked. Please try again later.',429);
if (!$user['email_verified'])
    fail('Please verify your email before signing in.',403);

$ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
$ua = substr($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown', 0, 80);
db()->prepare('UPDATE users SET login_attempts=0,locked_until=NULL,last_login_at=NOW(),last_login_ip=? WHERE id=?')
    ->execute([$ip,$user['id']]);

$token = create_session((int)$user['id']);
audit((int)$user['id'],'login',['method'=>'email','ip'=>$ip]);

// Send login alert email (async-safe: ignore failure)
@Mailer::sendLoginAlert($user['email'],$user['first_name'].' '.$user['last_name'],$ip,$ua);

ok([
    'token' => $token,
    'user'  => [
        'uuid'        => $user['uuid'],
        'email'       => $user['email'],
        'first_name'  => $user['first_name'],
        'last_name'   => $user['last_name'],
        'role'        => $user['role'],
        'kyc_status'  => $user['kyc_status'],
        'kyc_level'   => (int)$user['kyc_level'],
        'two_fa'      => (bool)$user['two_fa_enabled'],
        'referral_code'=> $user['referral_code'],
    ],
]);