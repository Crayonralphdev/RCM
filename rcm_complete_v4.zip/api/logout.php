<?php
// CORS headers first — before anything else can fail
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
// POST /api/logout.php
require_once __DIR__ . '/../includes/helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Method not allowed.', 405);

$header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
$token  = '';
if (preg_match('/Bearer\s+(\S+)/i', $header, $m)) $token = $m[1];
if (!$token) $token = $_COOKIE['rcm_token'] ?? '';

if ($token) {
    db()->prepare('DELETE FROM sessions WHERE token=?')->execute([$token]);
    setcookie('rcm_token', '', time() - 3600, '/', '', true, true);
}

ok(['message' => 'Signed out successfully.']);
