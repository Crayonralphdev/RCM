<?php
// CORS headers first — before anything else can fail
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

// Catch ALL errors and return as JSON instead of HTML
set_exception_handler(function($e) {
    echo json_encode(['success'=>false,'error'=>$e->getMessage(),'file'=>basename($e->getFile()),'line'=>$e->getLine()]);
    exit;
});
set_error_handler(function($severity, $msg, $file, $line) {
    echo json_encode(['success'=>false,'error'=>$msg,'file'=>basename($file),'line'=>$line]);
    exit;
});

require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../mail/Mailer.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo json_encode(['success'=>false,'error'=>'Method not allowed']); exit; }

$data = require_fields(['email','password','first_name','last_name','country']);

$email      = strtolower(trim($data['email']));
$password   = $data['password'];
$first_name = trim($data['first_name']);
$last_name  = trim($data['last_name']);
$country    = trim($data['country']);
$phone      = trim($data['phone'] ?? '');
$experience = $data['experience'] ?? 'beginner';
$ref_code   = strtoupper(trim($data['referral_code'] ?? ''));

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Invalid email address.');
if (strlen($password) < 8) fail('Password must be at least 8 characters.');
if (!preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password))
    fail('Password must contain at least one uppercase letter and one number.');

$valid_exp = ['beginner','some','intermediate','experienced','professional'];
if (!in_array($experience, $valid_exp)) $experience = 'beginner';

$check = db()->prepare('SELECT id FROM users WHERE email = ?');
$check->execute([$email]);
if ($check->fetch()) fail('An account with this email already exists.');

if ($ref_code) {
    $ref = db()->prepare('SELECT id FROM users WHERE referral_code = ?');
    $ref->execute([$ref_code]);
    if (!$ref->fetch()) fail('Invalid referral code.');
}

$uuid         = uuid4();
$hash         = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]); // cost 10 for speed on local
$my_ref_code  = gen_referral_code();
$verify_token = bin2hex(random_bytes(32));

db()->prepare(
    'INSERT INTO users (uuid,email,password_hash,first_name,last_name,phone,country,referral_code,referred_by,experience,verify_token)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)'
)->execute([$uuid,$email,$hash,$first_name,$last_name,$phone?:null,$country,$my_ref_code,$ref_code?:null,$experience,$verify_token]);

$user_id  = (int) db()->lastInsertId();
$fullname = "$first_name $last_name";

foreach (['USD','BTC','ETH','USDT'] as $cur) {
    db()->prepare('INSERT INTO wallets (user_id,currency,balance) VALUES (?,?,0)')->execute([$user_id,$cur]);
}

$otp      = create_otp($user_id, 'email_verify');
$mailSent = Mailer::sendVerifyOTP($email, $fullname, $otp);

audit($user_id, 'register', ['method'=>'email','country'=>$country]);

$res = [
    'success'      => true,
    'message'      => 'Account created. Check your email for the verification code.',
    'verify_token' => $verify_token,
    'email_sent'   => $mailSent,
];

// Always include OTP in response for local dev (no real email configured)
$res['_dev_otp'] = $otp;
$res['_notice']  = 'OTP included in response — remove this on live server';

http_response_code(201);
echo json_encode($res);
