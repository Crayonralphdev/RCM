<?php
// CORS headers first — before anything else can fail
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
// POST /api/reset-password.php
require_once __DIR__ . '/../includes/helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Method not allowed.', 405);

$data        = require_fields(['reset_token', 'password']);
$reset_token = trim($data['reset_token']);
$password    = $data['password'];

if (strlen($password) < 8 || !preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password))
    fail('Password must be at least 8 characters with 1 uppercase letter and 1 number.');

$stmt = db()->prepare('SELECT id, first_name FROM users WHERE reset_token=? AND reset_expires > NOW() LIMIT 1');
$stmt->execute([$reset_token]);
$user = $stmt->fetch();
if (!$user) fail('Reset link has expired or is invalid. Please request a new one.');

$hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
db()->prepare('UPDATE users SET password_hash=?, reset_token=NULL, reset_expires=NULL, login_attempts=0, locked_until=NULL WHERE id=?')
    ->execute([$hash, $user['id']]);

// Invalidate all existing sessions
db()->prepare('DELETE FROM sessions WHERE user_id=?')->execute([$user['id']]);

audit((int)$user['id'], 'password_reset', []);

ok(['message' => 'Password reset successfully. You can now sign in.']);
