<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$result = [
    'php_version' => phpversion(),
    'php_ok'      => version_compare(phpversion(), '7.4', '>='),
    'tests'       => []
];

try { require_once __DIR__ . '/../config/db.php'; $result['tests']['config'] = 'ok'; }
catch (Throwable $e) { $result['tests']['config'] = 'FAIL: ' . $e->getMessage(); }

try { db(); $result['tests']['db_connect'] = 'ok'; }
catch (Throwable $e) { $result['tests']['db_connect'] = 'FAIL: ' . $e->getMessage(); }

try {
    $count = db()->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $result['tests']['users_table'] = "ok ($count users)";
    $users = db()->query("SELECT email, email_verified, status FROM users LIMIT 3")->fetchAll();
    $result['tests']['seed_users'] = $users;
} catch (Throwable $e) { $result['tests']['users_table'] = 'FAIL: ' . $e->getMessage(); }

try { require_once __DIR__ . '/../includes/helpers.php'; $result['tests']['helpers'] = 'ok'; }
catch (Throwable $e) { $result['tests']['helpers'] = 'FAIL: ' . $e->getMessage(); }

try { require_once __DIR__ . '/../mail/Mailer.php'; $result['tests']['mailer'] = 'ok'; }
catch (Throwable $e) { $result['tests']['mailer'] = 'FAIL: ' . $e->getMessage(); }

echo json_encode($result, JSON_PRETTY_PRINT);
