<?php
// CORS headers first — before anything else can fail
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
// POST /api/verify-otp.php
require_once __DIR__ . '/../includes/helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Method not allowed.', 405);

$data         = require_fields(['verify_token','otp']);
$verify_token = trim($data['verify_token']);
$otp          = trim($data['otp']);

// ── Find user by verify token ─────────────────────────────────
$stmt = db()->prepare('SELECT * FROM users WHERE verify_token = ? AND email_verified = 0');
$stmt->execute([$verify_token]);
$user = $stmt->fetch();
if (!$user) fail('Invalid or already used verification token.');

// ── Check OTP ─────────────────────────────────────────────────
if (!verify_otp((int)$user['id'], $otp, 'email_verify'))
    fail('Invalid or expired code. Please request a new one.');

// ── Mark verified ─────────────────────────────────────────────
db()->prepare('UPDATE users SET email_verified=1, verify_token=NULL, kyc_level=1 WHERE id=?')
    ->execute([$user['id']]);

// ── Open session ──────────────────────────────────────────────
$token = create_session((int)$user['id']);

audit((int)$user['id'], 'email_verify', ['status' => 'verified']);

ok([
    'message' => 'Email verified. Welcome to Retro Clurix Miners!',
    'token'   => $token,
    'user'    => [
        'uuid'       => $user['uuid'],
        'email'      => $user['email'],
        'first_name' => $user['first_name'],
        'last_name'  => $user['last_name'],
    ],
]);