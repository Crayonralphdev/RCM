<?php
// CORS headers first — before anything else can fail
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
// POST /api/verify-reset-otp.php
require_once __DIR__ . '/../includes/helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Method not allowed.', 405);

$data  = require_fields(['email', 'otp']);
$email = strtolower(trim($data['email']));
$otp   = trim($data['otp']);

$stmt = db()->prepare('SELECT id FROM users WHERE email=? LIMIT 1');
$stmt->execute([$email]);
$user = $stmt->fetch();
if (!$user) fail('Invalid email address.', 404);

if (!verify_otp((int)$user['id'], $otp, 'password_reset'))
    fail('Invalid or expired code. Please request a new one.');

// Issue a short-lived reset token
$reset_token = bin2hex(random_bytes(32));
$expires     = date('Y-m-d H:i:s', time() + 900); // 15 minutes
db()->prepare('UPDATE users SET reset_token=?, reset_expires=? WHERE id=?')
    ->execute([$reset_token, $expires, $user['id']]);

ok(['reset_token' => $reset_token]);
