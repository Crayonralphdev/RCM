<?php
// ── Enable errors locally (comment out on live server) ───────
ini_set('display_errors', 1);
error_reporting(E_ALL);

define('DB_HOST',     'localhost');
define('DB_PORT',     3306);
define('DB_NAME',     'rcm_db');
define('DB_USER',     'root');   // XAMPP default
define('DB_PASS',     '');       // XAMPP default (no password)
define('DB_CHARSET',  'utf8mb4');

define('APP_URL', (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']==='on' ? 'https' : 'http')
    . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost'));
define('APP_SECRET',      'rcm_local_secret_key_change_on_live_2024');
define('SESSION_LIFETIME', 60 * 60 * 24 * 30);
define('OTP_EXPIRY_MIN',   10);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCK_DURATION_MIN',  15);

define('SMTP_HOST',     'smtp.sendgrid.net');
define('SMTP_PORT',     587);
define('SMTP_USER',     'apikey');
define('SMTP_PASS',     'YOUR_SENDGRID_API_KEY');
define('MAIL_FROM',     'noreply@retroclurixminers.net');
define('MAIL_FROM_NAME','Retro Clurix Miners');

function db() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s',
            DB_HOST, DB_PORT, DB_NAME, DB_CHARSET);
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}
