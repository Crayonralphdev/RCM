<?php
// ============================================================
//  Retro Clurix Miners — Shared Helpers
//  Place at:  includes/helpers.php
//  Requires:  config/db.php (included before this file)
// ============================================================
require_once __DIR__ . '/../config/db.php';

// ── CORS ──────────────────────────────────────────────────────
function cors(): void {
    // Always respond to the actual origin (or wildcard as fallback)
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '*';
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    header('Content-Type: application/json; charset=utf-8');
    // Handle preflight immediately — must exit before any redirect or output
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit;
    }
}

// ── JSON helpers ──────────────────────────────────────────────
function ok(array $data = [], int $code = 200) {
    http_response_code($code);
    echo json_encode(['success' => true] + $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function fail(string $error, int $code = 400) {
    http_response_code($code);
    echo json_encode(['success' => false, 'error' => $error], JSON_UNESCAPED_UNICODE);
    exit;
}

// ── Parse & validate JSON body ────────────────────────────────
function require_fields(array $fields): array {
    $raw  = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data)) fail('Invalid or missing JSON body.', 400);
    $errors = [];
    foreach ($fields as $f) {
        if (!isset($data[$f]) || (is_string($data[$f]) && trim($data[$f]) === ''))
            $errors[] = $f;
    }
    if ($errors) fail('Missing required fields: ' . implode(', ', $errors) . '.', 422);
    return $data;
}

// ── Auth: resolve Bearer token → user row ─────────────────────
function auth_user(): array {
    // Apache on XAMPP often strips Authorization header — check all locations
    $allHeaders = function_exists('apache_request_headers') ? apache_request_headers() : [];
    $header = $_SERVER['HTTP_AUTHORIZATION']
           ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
           ?? $allHeaders['Authorization']
           ?? $allHeaders['authorization']
           ?? '';
    $token = '';
    if (preg_match('/Bearer\s+(\S+)/i', $header, $m)) $token = $m[1];
    if (!$token) $token = $_COOKIE['rcm_token'] ?? '';
    if (!$token) fail('Unauthenticated.', 401);

    $stmt = db()->prepare(
        'SELECT u.* FROM sessions s
         JOIN users u ON u.id = s.user_id
         WHERE s.token = ? AND s.expires_at > NOW()
         LIMIT 1'
    );
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    if (!$user) fail('Session expired or invalid. Please sign in again.', 401);
    if ($user['status'] === 'banned')     fail('This account has been banned.', 403);
    if ($user['status'] === 'suspended')  fail('This account is suspended.', 403);
    return $user;
}

// ── Auth: require admin ───────────────────────────────────────
function auth_admin(): array {
    $user = auth_user();
    if ($user['role'] !== 'admin') fail('Forbidden: admin access required.', 403);
    return $user;
}

// ── Create a session token ────────────────────────────────────
function create_session(int $user_id): string {
    $token   = bin2hex(random_bytes(48));
    $expires = date('Y-m-d H:i:s', time() + SESSION_LIFETIME);
    $ip      = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $ua      = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);
    // Prune expired sessions for this user
    db()->prepare('DELETE FROM sessions WHERE user_id = ? AND expires_at < NOW()')->execute([$user_id]);
    db()->prepare(
        'INSERT INTO sessions (user_id, token, ip_address, user_agent, expires_at) VALUES (?,?,?,?,?)'
    )->execute([$user_id, $token, $ip, $ua, $expires]);
    return $token;
}

// ── OTP helpers ───────────────────────────────────────────────
function create_otp(int $user_id, string $purpose): string {
    $otp     = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $expires = date('Y-m-d H:i:s', time() + OTP_EXPIRY_MIN * 60);
    // Invalidate any existing unused OTPs for this user+purpose
    db()->prepare('UPDATE otp_codes SET used=1 WHERE user_id=? AND purpose=? AND used=0')
        ->execute([$user_id, $purpose]);
    db()->prepare('INSERT INTO otp_codes (user_id, code, purpose, expires_at) VALUES (?,?,?,?)')
        ->execute([$user_id, $otp, $purpose, $expires]);
    return $otp;
}

function verify_otp(int $user_id, string $code, string $purpose): bool {
    $stmt = db()->prepare(
        'SELECT id FROM otp_codes
         WHERE user_id=? AND code=? AND purpose=? AND used=0 AND expires_at > NOW()
         ORDER BY id DESC LIMIT 1'
    );
    $stmt->execute([$user_id, $code, $purpose]);
    $row = $stmt->fetch();
    if (!$row) return false;
    db()->prepare('UPDATE otp_codes SET used=1 WHERE id=?')->execute([$row['id']]);
    return true;
}

// ── UUID v4 ───────────────────────────────────────────────────
function uuid4(): string {
    $data    = random_bytes(16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

// ── Generate unique referral code ────────────────────────────
function gen_referral_code(): string {
    do {
        $code = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
        $stmt = db()->prepare('SELECT id FROM users WHERE referral_code = ?');
        $stmt->execute([$code]);
    } while ($stmt->fetch());
    return $code;
}

// ── Write to audit_log ────────────────────────────────────────
function audit(int $user_id, string $action, array $details = []): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    db()->prepare('INSERT INTO audit_log (user_id, action, ip_address, details) VALUES (?,?,?,?)')
        ->execute([$user_id, $action, $ip, json_encode($details)]);
}

// ── Wallet helpers ────────────────────────────────────────────
function get_wallet(int $user_id, string $currency): ?array {
    $stmt = db()->prepare('SELECT * FROM wallets WHERE user_id=? AND currency=? LIMIT 1');
    $stmt->execute([$user_id, $currency]);
    return $stmt->fetch() ?: null;
}

function credit_wallet(int $user_id, string $currency, float $amount): void {
    db()->prepare('UPDATE wallets SET balance = balance + ? WHERE user_id=? AND currency=?')
        ->execute([$amount, $user_id, $currency]);
}

function debit_wallet(int $user_id, string $currency, float $amount): void {
    $w = get_wallet($user_id, $currency);
    if (!$w || (float)$w['balance'] - (float)$w['locked'] < $amount)
        fail('Insufficient available balance.', 422);
    db()->prepare('UPDATE wallets SET balance = balance - ? WHERE user_id=? AND currency=?')
        ->execute([$amount, $user_id, $currency]);
}
