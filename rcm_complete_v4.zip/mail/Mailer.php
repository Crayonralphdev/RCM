<?php
// ============================================================
//  Retro Clurix Miners — Mailer
//  Place at:  mail/Mailer.php
//  Usage:     Mailer::sendVerifyOTP($email, $name, $otp);
//             Mailer::sendLoginAlert($email, $name, $ip, $ua);
//  Requires:  config/db.php  (for SMTP constants)
//  Optional:  vendor/autoload.php (PHPMailer via Composer)
//             composer require phpmailer/phpmailer
// ============================================================
require_once __DIR__ . '/../config/db.php';

class Mailer {

    // ── Send via SMTP (PHPMailer) or fallback to mail() ───────
    private static function send(string $to, string $name, string $subject, string $html): bool {
        // Skip actual sending on localhost — just log it
        $host = $_SERVER['HTTP_HOST'] ?? '';
        if ($host === 'localhost' || $host === '127.0.0.1') {
            error_log("[RCM Mailer] LOCAL — skipping email to {$to}: {$subject}");
            return false; // false = email not sent, _dev_otp will be in API response
        }

        $phpmailerPath = __DIR__ . '/../../vendor/autoload.php';
        if (file_exists($phpmailerPath)) {
            require_once $phpmailerPath;
            try {
                $mail = new PHPMailer\PHPMailer\PHPMailer(true);
                $mail->isSMTP();
                $mail->Host       = SMTP_HOST;
                $mail->SMTPAuth   = true;
                $mail->Username   = SMTP_USER;
                $mail->Password   = SMTP_PASS;
                $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = SMTP_PORT;
                $mail->CharSet    = 'UTF-8';
                $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
                $mail->addAddress($to, $name);
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body    = $html;
                $mail->AltBody = strip_tags(str_replace(
                    ['<br>', '<br/>', '<br />', '</p>', '</tr>', '</li>'],
                    "\n", $html
                ));
                $mail->send();
                error_log("[RCM Mailer] OK → {$to}: {$subject}");
                return true;
            } catch (\Exception $e) {
                error_log("[RCM Mailer] PHPMailer error: " . $e->getMessage());
            }
        }

        // Fallback: native mail()
        $headers  = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        $headers .= 'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM . ">\r\n";
        $headers .= "Reply-To: support@retroclurixminers.net\r\n";
        $headers .= 'X-Mailer: PHP/' . phpversion();
        $ok = mail($to, $subject, $html, $headers);
        if (!$ok) error_log("[RCM Mailer] mail() failed for {$to}");
        return $ok;
    }

    // ── Shared wrapper (also used by procedural includes/mailer.php) ──
    public static function raw(string $to, string $name, string $subject, string $html): bool {
        return self::send($to, $name, $subject, $html);
    }

    // ── Email verification OTP ────────────────────────────────
    public static function sendVerifyOTP(string $to, string $name, string $otp): bool {
        $digits = implode('', array_map(
            fn($d) => "<span style=\"display:inline-block;width:44px;height:52px;line-height:52px;text-align:center;background:#131827;border:1.5px solid rgba(240,192,64,0.35);border-radius:10px;font-size:26px;font-weight:700;color:#f0c040;font-family:'Courier New',monospace;margin:0 3px\">{$d}</span>",
            str_split($otp)
        ));
        $body = "
          <h2 style='font-size:22px;font-weight:800;color:#e2e6f0;margin:0 0 8px'>Verify your email</h2>
          <p style='font-size:14px;color:#8892aa;margin:0 0 24px'>Hi {$name}, enter this code to activate your account:</p>
          <div style='text-align:center;padding:24px;background:#131827;border-radius:12px;border:1px solid rgba(255,255,255,0.06);margin-bottom:24px'>
            {$digits}
            <p style='font-size:12px;color:#4a5468;margin:16px 0 0'>Expires in <strong style='color:#f0c040'>10 minutes</strong></p>
          </div>
          <div style='background:rgba(240,85,101,0.08);border:1px solid rgba(240,85,101,0.2);border-radius:10px;padding:14px 18px'>
            <p style='font-size:13px;color:#f05565;margin:0'>🔒 Never share this code. RCM staff will never ask for your OTP.</p>
          </div>";
        return self::send($to, $name, "Your RCM Verification Code: {$otp}", self::template('Email Verification', $body));
    }

    // ── Password reset OTP ─────────────────────────────────────
    public static function sendResetOTP(string $to, string $name, string $otp): bool {
        $digits = implode('', array_map(
            fn($d) => "<span style=\"display:inline-block;width:44px;height:52px;line-height:52px;text-align:center;background:#131827;border:1.5px solid rgba(240,192,64,0.35);border-radius:10px;font-size:26px;font-weight:700;color:#f0c040;font-family:'Courier New',monospace;margin:0 3px\">{$d}</span>",
            str_split($otp)
        ));
        $body = "
          <h2 style='font-size:22px;font-weight:800;color:#e2e6f0;margin:0 0 8px'>Reset your password</h2>
          <p style='font-size:14px;color:#8892aa;margin:0 0 24px'>Hi {$name}, here is your password reset code:</p>
          <div style='text-align:center;padding:24px;background:#131827;border-radius:12px;border:1px solid rgba(255,255,255,0.06);margin-bottom:24px'>
            {$digits}
            <p style='font-size:12px;color:#4a5468;margin:16px 0 0'>Expires in <strong style='color:#f0c040'>10 minutes</strong></p>
          </div>
          <p style='font-size:13px;color:#8892aa;margin:0'>If you did not request this, you can safely ignore this email.</p>";
        return self::send($to, $name, "Your RCM Password Reset Code: {$otp}", self::template('Password Reset', $body));
    }

    // ── Login alert ────────────────────────────────────────────
    public static function sendLoginAlert(string $to, string $name, string $ip, string $ua): bool {
        $time = date('D, d M Y H:i:s T');
        $dev  = self::parseDevice($ua);
        $body = "
          <h2 style='font-size:20px;font-weight:800;color:#e2e6f0;margin:0 0 8px'>New sign-in detected</h2>
          <p style='font-size:14px;color:#8892aa;margin:0 0 20px'>Hi {$name}, a new login to your account was detected.</p>
          <table width='100%' cellpadding='0' cellspacing='0' style='background:#131827;border-radius:10px;border:1px solid rgba(255,255,255,0.06);padding:18px;margin-bottom:20px'>
            <tr><td style='padding:7px 0;border-bottom:1px solid rgba(255,255,255,0.05)'><span style='color:#4a5468;font-size:12px;display:block'>Time</span><span style='color:#e2e6f0'>{$time}</span></td></tr>
            <tr><td style='padding:7px 0;border-bottom:1px solid rgba(255,255,255,0.05)'><span style='color:#4a5468;font-size:12px;display:block'>IP Address</span><span style='color:#e2e6f0;font-family:monospace'>{$ip}</span></td></tr>
            <tr><td style='padding:7px 0'><span style='color:#4a5468;font-size:12px;display:block'>Device</span><span style='color:#e2e6f0'>{$dev}</span></td></tr>
          </table>
          <div style='background:rgba(240,192,64,0.08);border:1px solid rgba(240,192,64,0.2);border-radius:10px;padding:14px 18px'>
            <p style='font-size:13px;color:#f0c040;margin:0'>Not you? <a href='https://retroclurixminers.net/signin.html' style='color:#f0c040;font-weight:700'>Change your password immediately →</a></p>
          </div>";
        return self::send($to, $name, 'New sign-in to your Retro Clurix Miners account', self::template('Login Alert', $body));
    }

    // ── Deposit confirmed (sent to user) ───────────────────────
    public static function sendDepositConfirmed(string $to, string $name, float $amount, string $currency, string $method): bool {
        $fmt  = '$' . number_format($amount, 2);
        $time = date('D, d M Y H:i:s T');
        $body = "
          <h2 style='font-size:20px;font-weight:800;color:#1fd98a;margin:0 0 8px'>✓ Deposit Confirmed</h2>
          <p style='font-size:14px;color:#8892aa;margin:0 0 20px'>Hi {$name}, your deposit has been credited to your account.</p>
          <div style='background:#131827;border-radius:12px;border:1px solid rgba(31,217,138,0.25);padding:28px;text-align:center;margin-bottom:20px'>
            <div style='font-size:38px;font-weight:800;color:#1fd98a;font-family:monospace'>{$fmt}</div>
            <div style='font-size:13px;color:#8892aa;margin-top:6px'>{$currency} via {$method}</div>
          </div>
          <table width='100%' cellpadding='0' cellspacing='0' style='background:#131827;border-radius:10px;border:1px solid rgba(255,255,255,0.06);padding:18px;margin-bottom:20px'>
            <tr><td style='padding:5px 0'><span style='color:#4a5468;font-size:12px'>Date</span><span style='float:right;color:#e2e6f0'>{$time}</span></td></tr>
            <tr><td style='padding:5px 0'><span style='color:#4a5468;font-size:12px'>Method</span><span style='float:right;color:#e2e6f0'>{$method}</span></td></tr>
            <tr><td style='padding:5px 0'><span style='color:#4a5468;font-size:12px'>Status</span><span style='float:right;color:#1fd98a;font-weight:700'>Confirmed</span></td></tr>
          </table>
          <div style='text-align:center'>
            <a href='https://retroclurixminers.net/dashboard.html' style='display:inline-block;padding:13px 32px;background:#f0c040;color:#0a0a0a;font-weight:800;font-size:14px;border-radius:9px;text-decoration:none'>
              Start Trading →
            </a>
          </div>";
        return self::send($to, $name, "Deposit of {$fmt} {$currency} confirmed", self::template('Deposit Confirmed', $body));
    }

    // ── Admin alert (deposit intent / submission / withdrawal) ─
    public static function sendAdminAlert(string $subject, string $body_html): bool {
        $html = self::template('Admin Alert', $body_html);
        return self::send('craralph@gmail.com', 'Admin', $subject, $html);
    }

    // ── Welcome email ──────────────────────────────────────────
    public static function sendWelcome(string $to, string $name, string $referral_code): bool {
        $body = "
          <h2 style='font-size:24px;font-weight:800;color:#e2e6f0;margin:0 0 8px'>Welcome aboard, {$name}! 🎉</h2>
          <p style='font-size:14px;color:#8892aa;margin:0 0 24px'>Your account is ready. Here's how to get started:</p>
          <div style='background:#131827;border-radius:12px;padding:20px;margin-bottom:14px;border:1px solid rgba(255,255,255,0.06)'>
            <strong style='color:#e2e6f0'>💳 Fund your account</strong>
            <p style='color:#8892aa;font-size:13px;margin:6px 0 0'>Deposit via Bitcoin, Ethereum, USDT, card or bank wire — zero deposit fees.</p>
          </div>
          <div style='background:#131827;border-radius:12px;padding:20px;margin-bottom:14px;border:1px solid rgba(255,255,255,0.06)'>
            <strong style='color:#e2e6f0'>📊 Start trading</strong>
            <p style='color:#8892aa;font-size:13px;margin:6px 0 0'>100+ markets — crypto, forex, commodities &amp; indices. Up to 100× leverage.</p>
          </div>
          <div style='background:#131827;border-radius:12px;padding:20px;margin-bottom:24px;border:1px solid rgba(255,255,255,0.06)'>
            <strong style='color:#e2e6f0'>🤝 Refer &amp; earn</strong>
            <p style='color:#8892aa;font-size:13px;margin:6px 0 0'>Your code: <strong style='color:#f0c040;font-family:monospace'>{$referral_code}</strong> — earn up to 40% commission on referrals.</p>
          </div>
          <div style='text-align:center'>
            <a href='https://retroclurixminers.net/dashboard.html' style='display:inline-block;padding:14px 32px;background:#f0c040;color:#0a0a0a;font-weight:800;font-size:15px;border-radius:9px;text-decoration:none'>
              Go to My Dashboard →
            </a>
          </div>";
        return self::send($to, $name, 'Welcome to Retro Clurix Miners — your account is ready!', self::template('Welcome', $body));
    }

    // ── Shared HTML email shell ────────────────────────────────
    public static function template(string $title, string $body): string {
        $year = date('Y');
        return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{$title}</title></head>
<body style="margin:0;padding:0;background:#050a18;font-family:'Helvetica Neue',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#050a18;padding:40px 20px">
  <tr><td align="center">
    <table width="560" cellpadding="0" cellspacing="0" style="background:#0e1525;border-radius:16px;border:1px solid rgba(255,255,255,0.08);overflow:hidden;max-width:560px;width:100%">
      <tr><td style="background:linear-gradient(135deg,#0f1d3a,#1a1200);padding:32px 40px;text-align:center;border-bottom:1px solid rgba(255,255,255,0.08)">
        <div style="font-size:22px;font-weight:800;color:#e2e6f0;letter-spacing:-0.5px">Retro Clurix <span style="color:#f0c040">Miners</span></div>
        <div style="font-size:12px;color:#4a5468;margin-top:4px">Your trusted trading platform</div>
      </td></tr>
      <tr><td style="padding:36px 40px">{$body}</td></tr>
      <tr><td style="padding:24px 40px;border-top:1px solid rgba(255,255,255,0.06);text-align:center">
        <p style="font-size:11px;color:#4a5468;margin:0 0 6px">&copy; {$year} Retro Clurix Miners Trading Services LLC &middot; St. Vincent &amp; the Grenadines</p>
        <p style="font-size:11px;color:#4a5468;margin:0">If you did not perform this action, <a href="mailto:security@retroclurixminers.net" style="color:#f0c040">contact support</a>.</p>
      </td></tr>
    </table>
  </td></tr>
</table>
</body>
</html>
HTML;
    }

    // ── Parse device string from user agent ────────────────────
    private static function parseDevice(string $ua): string {
        $ua = substr($ua, 0, 200);
        if (stripos($ua, 'iPhone') !== false)   return 'iPhone (iOS)';
        if (stripos($ua, 'iPad') !== false)     return 'iPad (iOS)';
        if (stripos($ua, 'Android') !== false)  return 'Android device';
        if (stripos($ua, 'Mac OS X') !== false) return 'Mac desktop';
        if (stripos($ua, 'Windows') !== false)  return 'Windows desktop';
        if (stripos($ua, 'Linux') !== false)    return 'Linux desktop';
        return 'Unknown device';
    }
}

// ── Procedural aliases (used by includes/mailer.php calls in dashboard.php) ──
function send_email(string $to, string $name, string $subject, string $html): bool {
    return Mailer::raw($to, $name, $subject, $html);
}
function email_template(string $title, string $body): string {
    return Mailer::template($title, $body);
}
function email_deposit_confirmed(string $to, string $name, string $amount, string $currency, string $method): bool {
    return Mailer::sendDepositConfirmed($to, $name, (float) str_replace(['$', ','], '', $amount), $currency, $method);
}
